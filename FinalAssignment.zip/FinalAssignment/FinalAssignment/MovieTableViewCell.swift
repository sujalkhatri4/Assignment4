//
//  MovieTableViewCell.swift
//  FinalAssignment
//
//  Created by Jatin Antil on 2024-08-11.
//

import UIKit
import FirebaseFirestore

class MovieTableViewCell: UITableViewCell {
  
    @IBOutlet weak var posterImageView: UIImageView!
  
    @IBOutlet weak var titleLabel: UITextField!
  
    @IBOutlet weak var studioLabel: UITextField!
   
    @IBOutlet weak var ratingLabel: UITextField!
}
